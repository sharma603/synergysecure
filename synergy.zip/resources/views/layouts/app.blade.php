<!-- Replace school-related menu items with company ones -->
<li class="nav-item">
    <a class="nav-link" href="{{ route('admin.companies.index') }}">
        Companies
    </a>
</li>